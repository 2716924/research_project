#!/bin/bash
# One command to start the PER loss-history rerun:
#     bash submit_per_rerun.sh            # all 8 tasks
#     bash submit_per_rerun.sh 0-3        # only some tasks (e.g. if the job limit is lower)
# Works from any directory. Checks the environment first, so a mismatch fails here
# instead of in queued jobs. Finished individuals are skipped, so rerunning is safe.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
ARRAY="${1:-0-7}"

PYTHON="${RCT_PYTHON:-$HOME/.conda/envs/mltest/bin/python}"
if [[ ! -x "$PYTHON" ]]; then
    echo "ERROR: mltest environment not found at $PYTHON (set RCT_PYTHON to override)"
    exit 1
fi

echo "Checking environment against the reported PER results..."
SLURM_CPUS_PER_TASK=4 "$PYTHON" rerun_per_individual.py --check-only

echo ""
echo "Jobs you already have in the queue: $(squeue -h -u "$USER" | wc -l)"
echo "  (they count towards the cluster's per-user submit limit; see them with: squeue -u \$USER)"

# Create every folder the jobs write to now, one at a time on the login node. Jobs that
# start together and create the same new folders can fail with "mkdir: Already exists".
mkdir -p logs/per-loss-rerun
for slug in breakout asterix freeway spaceinvaders; do
    for k in $(seq -w 0 12); do
        mkdir -p "experiments/per-loss-rerun/full/results/per/${slug}/individual-${k}" \
                 "experiments/per-loss-rerun/full/tracking/per/${slug}/individual-${k}"
    done
done
echo "Created output folders under $ROOT/experiments/per-loss-rerun/"

sbatch --chdir="$ROOT" --array="$ARRAY" slurm/rerun_per_losses.slurm

echo ""
echo "Submitted tasks ${ARRAY}. Each task runs 6-7 PER individuals in a row (about 1.5-2 days)."
echo "Monitor with: squeue -u \$USER     Logs: $ROOT/logs/per-loss-rerun/"
echo "When all have finished, run: $PYTHON compare_rerun.py"
