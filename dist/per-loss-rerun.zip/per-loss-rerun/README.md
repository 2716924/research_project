# PER loss-history rerun

Reruns PER individuals 0–12 on Breakout, Asterix, Freeway and Space Invaders (52 runs)
to recover their training-loss histories. The results for these individuals already
exist. This rerun only regenerates the logs that were lost, so it must reproduce the
reported runs exactly.

## Run it

```bash
unzip per-loss-rerun.zip
bash per-loss-rerun/submit_per_rerun.sh
```

Use the submit script rather than calling `sbatch` yourself. It works from any
directory, checks the environment, and sets the working directory so the logs and
code are found.

It submits **8 tasks**, two per game: individuals 0–6 and 7–12, run one after another.
PER individuals take 5–6.3 hours each, so a task needs at most about 45 hours, within
the 3-day limit. Resources match the original jobs: bigbatch, 4 CPUs, 16 GB, exclusive
node.

| Task | Game | Individuals |
|---|---|---|
| 0 / 1 | Breakout | 0–6 / 7–12 |
| 2 / 3 | Asterix | 0–6 / 7–12 |
| 4 / 5 | Freeway | 0–6 / 7–12 |
| 6 / 7 | Space Invaders | 0–6 / 7–12 |

**Job limit.** The cluster limits how many jobs you can have queued at once, and each
task counts as one. If 8 is too many (check `squeue -u $USER` for jobs already queued),
submit in parts, e.g. `bash submit_per_rerun.sh 0-3` now and `bash submit_per_rerun.sh 4-7`
once those finish.

**Safe to resubmit.** Finished individuals are skipped. If a task runs short of time,
it resubmits itself (one queued job) and carries on from the next unfinished individual.

When everything has finished:

```bash
cd per-loss-rerun
~/.conda/envs/mltest/bin/python compare_rerun.py
```

Every row should say `MATCH`, meaning the rerun's evaluation curve is identical to the
reported one, so its loss history belongs to the reported run. Then zip
`experiments/per-loss-rerun/` and `logs/per-loss-rerun/` and bring them back.

## Requirements

It runs only in an environment identical to the one that produced the PER results.
`submit_per_rerun.sh` and every task check this before training, and stop with exit
code 3 on any difference:

| | Required |
|---|---|
| Code | bundled `rct/` (SHA-256 matched to the results) |
| Python | 3.11.14 (`~/.conda/envs/mltest`, or set `RCT_PYTHON`) |
| Packages | numpy 2.4.2, torch 2.13.0, gymnasium 1.3.0, minatar 1.0.15 |
| Threads | 4 (`--cpus-per-task=4`) |

Do not change the code, the CPU count or the environment. `RCT_ALLOW_MISMATCH=1`
overrides the check, but the resulting losses would not belong to the reported runs.

## If something fails

`compare_rerun.py` lists runs that are `not run` or `MISMATCH`. Resubmit the task for
that game and half from the table above, e.g. `bash submit_per_rerun.sh 5`.
Its finished individuals are skipped.

## Contents

| Path | What |
|---|---|
| `rct/`, `run_rct.py`, `verify_arms.py`, `tests/`, `slurm/common.sh` | Code exactly as deployed for corrected-rct-01 (Cluster A) |
| `rerun_per_individual.py` | Runs one individual through the unmodified `rct.trial.execute_rct_trial` |
| `slurm/rerun_per_losses.slurm` | The 8-task array |
| `submit_per_rerun.sh` | The one command |
| `compare_rerun.py` | Checks reruns against `reference/` |
| `reference/` | The reported PER results, used for the checks |

Output goes to `experiments/per-loss-rerun/full/{results,tracking}/per/<game>/individual-NN/`
and `logs/per-loss-rerun/`. Each individual trains as a cohort of one, so the log prints
`Individual 8/1` for individual 7. That label is expected.
