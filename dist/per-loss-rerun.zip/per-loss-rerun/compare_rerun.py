"""Check that every rerun PER individual reproduced its reported result exactly.

A rerun's loss history is usable only if its evaluation trajectory equals the
reported one. Writes rerun_check.csv and prints a summary.

    python compare_rerun.py
"""
import csv
import json
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE / "experiments/per-loss-rerun/full"
SLUGS = {"breakout": "Breakout", "asterix": "Asterix", "freeway": "Freeway", "spaceinvaders": "SpaceInvaders"}


def main():
    rows = []
    for slug, name in SLUGS.items():
        ref = {r["individual_id"]: r for r in
               json.loads((HERE / f"reference/per_results_MinAtar_{name}-v1.json").read_text())["results"]}
        for k in range(13):
            sub = f"individual-{k:02d}"
            out = ROOT / "results/per" / slug / sub / f"per_results_MinAtar_{name}-v1.json"
            row = dict(game=slug, individual=k, status="not run", attempt_id="", tracking_file="")
            if out.exists():
                runs = [r for r in json.loads(out.read_text())["results"] if r["individual_id"] == k]
                if runs:
                    run = runs[0]
                    row["attempt_id"] = run["attempt_id"]
                    same = run["eval_trajectory"] == ref[k]["eval_trajectory"]
                    row["status"] = "MATCH" if same else "MISMATCH"
                    track = ROOT / "tracking/per" / slug / sub / f"attempt-{run['attempt_id']}.jsonl"
                    row["tracking_file"] = str(track.relative_to(HERE)) if track.exists() else "MISSING"
            rows.append(row)
    with open(HERE / "rerun_check.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0]))
        w.writeheader()
        w.writerows(rows)
    for status in ("MATCH", "MISMATCH", "not run"):
        cells = [f"{r['game']}/{r['individual']}" for r in rows if r["status"] == status]
        print(f"{status:9} {len(cells):2}  {' '.join(cells) if status != 'MATCH' else ''}")
    missing = [r for r in rows if r["tracking_file"] == "MISSING"]
    if missing:
        print("Tracking file missing for:", " ".join(f"{r['game']}/{r['individual']}" for r in missing))
    print("Details: rerun_check.csv")


if __name__ == "__main__":
    main()
