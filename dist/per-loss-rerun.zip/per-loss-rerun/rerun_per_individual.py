"""Rerun one PER individual to regenerate its training-loss history.

Training uses the unmodified corrected-rct-01 code path, rct.trial.execute_rct_trial,
with the cohort narrowed to one individual. Individuals are drawn sequentially from
a fixed seed (rct/sampling.py), so individual k is identical whatever cohort size
is sampled, and every individual reseeds its own training.

Before any training, the run metadata (source hashes, Python and package versions,
torch thread count, protocol) must equal the metadata stored with the reported PER
results in reference/. Otherwise the rerun cannot reproduce those results, so it
refuses to start.

    python rerun_per_individual.py --game MinAtar/Breakout-v1 --individual 0 \
        --output-dir OUT --tracking-dir TRACK
    python rerun_per_individual.py --check-only     # environment check, all games
"""
import argparse
import json
import os
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
GAMES = ["MinAtar/Breakout-v1", "MinAtar/Asterix-v1", "MinAtar/Freeway-v1", "MinAtar/SpaceInvaders-v1"]
PROTOCOL = dict(total_frames=5_000_000, eval_frequency=50_000, num_eval_episodes=10)


def reference(game_id):
    name = game_id.split("/")[1]
    return json.loads((HERE / "reference" / f"per_results_MinAtar_{name}.json").read_text())


def check_metadata(game_id):
    # Training sets torch threads from SLURM_CPUS_PER_TASK in rct/torch_setup.py, so
    # load it first; otherwise the check sees torch's default (all cores on the node).
    import rct.torch_setup  # noqa: F401
    from rct.results import build_metadata

    expected = {k: v for k, v in reference(game_id).items() if k != "results"}
    actual = build_metadata("per", game_id, **PROTOCOL)
    problems = []
    for key in sorted(set(expected) | set(actual)):
        if key == "provenance":
            continue
        if expected.get(key) != actual.get(key):
            problems.append(f"{key}: expected {expected.get(key)!r}, got {actual.get(key)!r}")
    exp_p, act_p = expected["provenance"], actual["provenance"]
    for key in ("python_version", "torch_num_threads"):
        if exp_p[key] != act_p[key]:
            problems.append(f"{key}: expected {exp_p[key]!r}, got {act_p[key]!r}")
    for name, ver in exp_p["package_versions"].items():
        if act_p["package_versions"].get(name) != ver:
            problems.append(f"package {name}: expected {ver}, got {act_p['package_versions'].get(name)}")
    for name, digest in exp_p["source_sha256"].items():
        if act_p["source_sha256"].get(name) != digest:
            problems.append(f"source rct/{name} differs from the code that produced the results")
    return problems


def require_matching_environment(games):
    problems = sorted({p for g in games for p in check_metadata(g)})
    if problems:
        print("ENVIRONMENT MISMATCH — this rerun would not reproduce the reported PER results:")
        for p in problems:
            print("  -", p)
        if os.environ.get("RCT_ALLOW_MISMATCH") != "1":
            print("Refusing to train. Fix the environment, or set RCT_ALLOW_MISMATCH=1 to run anyway.")
            sys.exit(3)
        print("RCT_ALLOW_MISMATCH=1 set — continuing; losses may not match the reported runs.")
    else:
        print("Environment matches the reported PER results (code, Python, packages, threads).")


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--game", choices=GAMES)
    parser.add_argument("--individual", type=int, choices=range(13))
    parser.add_argument("--output-dir")
    parser.add_argument("--tracking-dir")
    parser.add_argument("--wandb-mode", default=os.environ.get("WANDB_MODE", "offline"),
                        choices=["disabled", "offline", "online"])
    parser.add_argument("--experiment-id", default="per-loss-rerun/full")
    parser.add_argument("--check-only", action="store_true", help="Only run the environment check")
    args = parser.parse_args()

    if args.check_only:
        require_matching_environment(GAMES)
        return
    if None in (args.game, args.individual, args.output_dir, args.tracking_dir):
        parser.error("--game, --individual, --output-dir and --tracking-dir are required")

    require_matching_environment([args.game])

    import rct.trial as trial
    from rct.sampling import sample_individuals
    from rct.tracking import TrackingSettings

    individual = sample_individuals(args.individual + 1)[args.individual]
    ref = next(r for r in reference(args.game)["results"] if r["individual_id"] == args.individual)
    assert (individual["seed"], individual["config"]) == (ref["seed"], ref["config"]), "cohort mismatch"
    trial.sample_individuals = lambda n: [individual]

    tracking = TrackingSettings(mode=args.wandb_mode, project=os.environ.get("WANDB_PROJECT", "dqn-rct"),
                                entity=os.environ.get("WANDB_ENTITY", "2716924-wits"),
                                directory=args.tracking_dir, experiment_id=args.experiment_id)
    tracking.validate()

    print("Running algorithm and result-integrity preflight checks...", flush=True)
    subprocess.run([sys.executable, str(HERE / "verify_arms.py")], check=True)

    stopped_early = trial.execute_rct_trial(variant="per", num_individuals=1, output_dir=args.output_dir,
                                            games=[args.game], pilot=False, log_every=1000,
                                            tracking=tracking, **PROTOCOL)
    sys.exit(2 if stopped_early else 0)


if __name__ == "__main__":
    main()
