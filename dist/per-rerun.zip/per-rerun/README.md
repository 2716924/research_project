# PER loss-history rerun (regular SLURM script)

Reruns PER individuals 0–12 on Breakout, Asterix, Freeway and Space Invaders (52 runs) to
recover their training-loss histories. Their results already exist. The rerun must
reproduce them exactly, and `check_per_rerun.py` verifies that it does.

This uses the regular `slurm/run_rct_bigbatch_variant.slurm` and `run_rct.py`, the same
path that produced the PER results. Individuals are drawn in a fixed order from a fixed
seed, so `RCT_NUM_INDIVIDUALS=13` trains exactly individuals 0–12 with their original
seeds and settings.

## Why the previous bundle failed

`per-loss-rerun.zip` did not include `sync_wandb.py`. The preflight check (`verify_arms.py`)
imports it through `tests/test_cluster_tracking.py`, failed, and stopped every individual
before training. This bundle includes it, and the preflight passes (38 tests).

## Run it

Run these from inside the unzipped folder:

```bash
unzip per-rerun.zip && cd per-rerun

# 1. Environment check. It must print OK; if it does not, do not submit.
~/.conda/envs/mltest/bin/python check_per_rerun.py env

# 2. Create the folders first, so tasks starting together don't race on mkdir.
mkdir -p logs/rct-bigbatch-variant
for g in breakout asterix freeway spaceinvaders; do
    mkdir -p experiments/per-loss-rerun-02/full/results/per/$g experiments/per-loss-rerun-02/full/tracking/per/$g
done

# 3. Submit. Tasks 10-13 are PER x Breakout, Asterix, Freeway, Space Invaders.
RCT_EXPERIMENT_ID=per-loss-rerun-02 RCT_NUM_INDIVIDUALS=13 \
    sbatch --array=10-13 slurm/run_rct_bigbatch_variant.slurm
```

This submits 4 jobs, one per game. Each runs individuals 0–12 in order (5–6.3 h each,
65–82 h in all). A job stops cleanly before the 3-day limit and resubmits itself with the
same settings, so expect one resubmission per game and about 3.5 days in total.
Finished individuals are always skipped.

Cancel any jobs left over from the old bundle first. They cannot train:
`scancel -n per-loss-rerun`.

## While it runs

```bash
~/.conda/envs/mltest/bin/python check_per_rerun.py live
```

This compares every evaluation logged so far with the reported curve. The first
evaluation comes about 50k frames into each individual, under an hour after it starts.
Every line should say `MATCH`. A `MISMATCH` means the rerun is not reproducing the
reported run, so `scancel` the jobs and investigate. Logs are in `logs/rct-bigbatch-variant/`.

## When finished

```bash
~/.conda/envs/mltest/bin/python check_per_rerun.py final
```

It should print `ALL 52 MATCH`. That means: 13/13 individuals per game, evaluation curves
identical to the reported ones, the same code, Python, packages and threads, and a
completed loss log for every run. Then bring back
`experiments/per-loss-rerun-02/`, `logs/rct-bigbatch-variant/` and `rerun_check.csv`:

```bash
zip -r per-rerun-output.zip experiments/per-loss-rerun-02 logs/rct-bigbatch-variant rerun_check.csv
```

If a game ends short (`not run`), resubmit only its task, e.g. Freeway:
`RCT_EXPERIMENT_ID=per-loss-rerun-02 RCT_NUM_INDIVIDUALS=13 sbatch --array=12 slurm/run_rct_bigbatch_variant.slurm`.

## Contents

| Path | What |
|---|---|
| `rct/`, `run_rct.py`, `verify_arms.py`, `sync_wandb.py`, `tests/`, `slurm/common.sh` | Code as deployed for corrected-rct-01 Cluster A (`rct/` SHA-256 matches the PER results) |
| `slurm/run_rct_bigbatch_variant.slurm` | The regular script. The only change: the cohort size reads `RCT_NUM_INDIVIDUALS` (default 30) |
| `check_per_rerun.py` | `env` / `live` / `final` checks against `reference/` |
| `reference/` | The reported PER results |
