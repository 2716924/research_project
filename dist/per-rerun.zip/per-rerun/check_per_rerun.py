"""Checks for the PER loss-history rerun (individuals 0-12, four games).

A rerun's loss history belongs to a reported run only if the rerun reproduced
that run's evaluation curve exactly. These checks compare against reference/,
the reported PER results.

    python check_per_rerun.py env      # before sbatch: code, Python, packages match
    python check_per_rerun.py live     # while running: every evaluation so far matches
    python check_per_rerun.py final    # at the end: 13/13 per game, all MATCH, loss logs present

Exit code 0 = all good, 1 = a problem was found (printed).
"""
import argparse
import csv
import json
import os
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
EXPERIMENT_ID = "per-loss-rerun-02"
GAMES = {"breakout": "Breakout", "asterix": "Asterix", "freeway": "Freeway", "spaceinvaders": "SpaceInvaders"}
INDIVIDUALS = range(13)


def reference(slug):
    return json.loads((HERE / f"reference/per_results_MinAtar_{GAMES[slug]}-v1.json").read_text())


def provenance_problems(expected, actual):
    problems = [f"{k}: expected {expected[k]!r}, got {actual.get(k)!r}"
                for k in ("python_version", "torch_num_threads") if expected[k] != actual.get(k)]
    for name, ver in expected["package_versions"].items():
        if actual["package_versions"].get(name) != ver:
            problems.append(f"package {name}: expected {ver}, got {actual['package_versions'].get(name)}")
    for name, digest in expected["source_sha256"].items():
        if actual["source_sha256"].get(name) != digest:
            problems.append(f"rct/{name} differs from the code that produced the reported results")
    extra = set(actual["source_sha256"]) - set(expected["source_sha256"])
    problems += [f"rct/{name} did not exist in the reported code" for name in sorted(extra)]
    return problems


def check_env():
    # sbatch sets SLURM_CPUS_PER_TASK=4 (--cpus-per-task=4); rct/torch_setup.py sizes torch from it.
    os.environ.setdefault("SLURM_CPUS_PER_TASK", "4")
    sys.path.insert(0, str(HERE))
    import rct.torch_setup  # noqa: F401
    from rct.results import build_metadata

    problems = set()
    for slug, name in GAMES.items():
        ref = reference(slug)
        actual = build_metadata("per", ref["game_id"], ref["total_frames"], ref["eval_frequency"],
                                ref["num_eval_episodes"])
        for key in actual:
            if key != "provenance" and actual[key] != ref.get(key):
                problems.add(f"{key} differs from the reported results")
        problems.update(provenance_problems(ref["provenance"], actual["provenance"]))
    if problems:
        print("ENVIRONMENT MISMATCH - the rerun would not reproduce the reported PER results:")
        for p in sorted(problems):
            print("  -", p)
        return 1
    print("OK  environment matches the reported PER results (code SHA-256, Python, packages, threads)")
    return 0


def read_attempt(path):
    start, evals, finish, losses = None, [], None, 0
    for line in path.read_text().splitlines():
        record = json.loads(line)
        if record["event"] == "start":
            start = record["config"]
        elif record["event"] == "finish":
            finish = record
        elif "eval/mean_return" in record:
            evals.append(record["eval/mean_return"])
        elif "train/loss" in record:
            losses += 1
    return start, evals, finish, losses


def check_live(root):
    bad = 0
    found = False
    for slug in GAMES:
        ref = {r["individual_id"]: r["eval_trajectory"] for r in reference(slug)["results"]}
        for path in sorted((root / "tracking/per" / slug).glob("attempt-*.jsonl")):
            found = True
            start, evals, finish, losses = read_attempt(path)
            if start is None:
                continue
            k = start["individual_id"]
            same = evals == ref[k][:len(evals)]
            state = finish["status"] if finish else "running"
            bad += not same
            print(f"{'MATCH' if same else 'MISMATCH':8} {slug:13} individual {k:2}  "
                  f"{len(evals):3}/100 evals  {losses:4} loss rows  {state}")
            if not same:
                i = next(i for i, (a, b) in enumerate(zip(evals, ref[k])) if a != b)
                print(f"         first difference at frame {(i + 1) * 50_000}: got {evals[i]}, reported {ref[k][i]}")
    if not found:
        print(f"No attempts yet under {root}/tracking/per/")
    if bad:
        print("\nA MISMATCH means the rerun is not reproducing the reported run: cancel the jobs (scancel).")
    return 1 if bad else 0


def check_final(root):
    rows = []
    for slug, name in GAMES.items():
        ref_data = reference(slug)
        ref = {r["individual_id"]: r for r in ref_data["results"]}
        out = root / f"results/per/{slug}/per_results_MinAtar_{name}-v1.json"
        data = json.loads(out.read_text()) if out.exists() else {"results": []}
        if out.exists():
            for p in provenance_problems(ref_data["provenance"], data["provenance"]):
                print(f"PROVENANCE {slug}: {p}")
                rows.append(dict(game=slug, individual="", status="PROVENANCE MISMATCH", attempt_id="",
                                 loss_rows="", tracking_file=p))
        runs = {r["individual_id"]: r for r in data["results"]}
        for k in sorted(set(INDIVIDUALS) | set(runs)):
            row = dict(game=slug, individual=k, status="not run", attempt_id="", loss_rows="", tracking_file="")
            run = runs.get(k)
            if k not in INDIVIDUALS:
                row["status"] = "UNEXPECTED"
            elif run is not None:
                row["attempt_id"] = run["attempt_id"]
                row["status"] = "MATCH" if run["eval_trajectory"] == ref[k]["eval_trajectory"] else "MISMATCH"
                track = root / f"tracking/per/{slug}/attempt-{run['attempt_id']}.jsonl"
                if track.exists():
                    start, evals, finish, losses = read_attempt(track)
                    row["loss_rows"] = losses
                    row["tracking_file"] = os.path.relpath(track, HERE)
                    if evals != run["eval_trajectory"] or not finish or finish["status"] != "completed":
                        row["status"] = "TRACKING INCOMPLETE"
                else:
                    row["tracking_file"] = "MISSING"
                    row["status"] = "TRACKING MISSING"
            rows.append(row)
    with open(HERE / "rerun_check.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    statuses = sorted({r["status"] for r in rows})
    for status in statuses:
        cells = [f"{r['game']}/{r['individual']}" for r in rows if r["status"] == status]
        print(f"{status:20} {len(cells):2}  {' '.join(cells) if status != 'MATCH' else ''}")
    ok = statuses == ["MATCH"] and len(rows) == len(GAMES) * len(INDIVIDUALS)
    print("\nALL 52 MATCH - zip experiments/ and logs/ and bring them back." if ok else "\nNot finished or not clean yet.")
    print("Details: rerun_check.csv")
    return 0 if ok else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("mode", choices=["env", "live", "final"])
    parser.add_argument("--root", default=str(HERE / "experiments" / EXPERIMENT_ID / "full"),
                        help="experiment folder holding results/ and tracking/")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    sys.exit({"env": check_env, "live": lambda: check_live(root), "final": lambda: check_final(root)}[args.mode]())


if __name__ == "__main__":
    main()
